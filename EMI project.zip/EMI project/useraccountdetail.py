from tkinter import *
from tkinter import messagebox
import pymysql
pymysql.install_as_MySQLdb()
from tkinter.ttk import Combobox
from PIL import Image,ImageTk

def first():
  con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
  cursor = con.cursor()
  cursor.execute("select * from usermaster limit 1")
  rows = cursor.fetchall()
  for row in rows:
    userid.insert(0, row[0])
    username.insert(0, row[1])
    password.insert(0, row[2])
    usertype.insert(0, row[3])
    userstatus.insert(0, row[4])
    securityquestion.insert(0, row[5])
    securityanswer.insert(0, row[6])
  con.close()

def previous():
  con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
  cursor = con.cursor()
  cursor.execute("select * from usermaster limit 1")
  rows = cursor.fetchall()
  for row in rows:
    userid.insert(0, row[0])
    username.insert(0, row[1])
    password.insert(0, row[2])
    usertype.insert(0, row[3])
    userstatus.insert(0, row[4])
    securityquestion.insert(0, row[5])
    securityanswer.insert(0, row[6])
  con.close()

def next1():
  con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
  cursor = con.cursor()
  cursor.execute("select * from usermaster limit 1")
  rows = cursor.fetchall()
  for row in rows:
    userid.insert(0, row[0])
    username.insert(0, row[1])
    password.insert(0, row[2])
    usertype.insert(0, row[3])
    userstatus.insert(0, row[4])
    securityquestion.insert(0, row[5])
    securityanswer.insert(0, row[6])
  con.close()

def last():
  con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator")
  cursor = con.cursor()
  cursor.execute("select * from usermaster order by userid desc limit 1")
  rows = cursor.fetchall()
  for row in rows:
    userid.insert(0, row[0])
    username.insert(0, row[1])
    password.insert(0, row[2])
    usertype.insert(0, row[3])
    userstatus.insert(0, row[4])
    securityquestion.insert(0, row[5])
    securityanswer.insert(0, row[6])
  con.close()

def add():
  uid = userid.get()
  uname = username.get()
  passwd = password.get()
  utype = usertype.get()
  ustatus = userstatus.get()
  securityq = securityquestion.get()
  securitya = securityanswer.get()
  if(uid =="" and uname =="" and passwd==""):
    messagebox.showinfo("Insert Status","All * Fields are required")
  else:
    con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator") 
    cursor = con.cursor()
    cursor.execute("insert into usermaster values('"+ uid +"','"+ uname +"','"+ passwd +"','"+ utype +"','"+ ustatus +"','"+ securityq +"','"+ securitya +"')")
    cursor.execute("commit")

    userid.delete(0, 'end')
    username.delete(0, 'end')
    password.delete(0, 'end')
    securityquestion.delete(0, 'end')
    securityanswer.delete(0, 'end')
    messagebox.showinfo("Insert Status","Insert successfully")
    con.close()

def save():
  uid = userid.get()
  uname = username.get()
  passwd = password.get()
  utype = usertype.get()
  ustatus = userstatus.get()
  securityq = securityquestion.get()
  securitya = securityanswer.get()
  if(uid =="" and uname =="" and passwd==""):
    messagebox.showinfo("Insert Status","All * Fields are required")
  else:
    con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator") 
    cursor = con.cursor()
    cursor.execute("insert into usermaster values('"+ uid +"','"+ uname +"','"+ passwd +"','"+ utype +"','"+ ustatus +"','"+ securityq +"','"+ securitya +"')")
    cursor.execute("commit")

    userid.delete(0, 'end')
    username.delete(0, 'end')
    password.delete(0, 'end')
    securityquestion.delete(0, 'end')
    securityanswer.delete(0, 'end')
    messagebox.showinfo("Insert Status","Insert successfully")
    con.close()

def update():
  uid = userid.get()
  uname = username.get()
  passwd = password.get()
  securityq = securityquestion.get()
  securitya = securityanswer.get()
  if(uid =="" and uname =="" and passwd== ""):
    messagebox.showinfo("update Status","All * Fields are required")
  else:
    con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator") 
    cursor = con.cursor()
    cursor.execute("update usermaster set  username ='"+ uname +"', password ='"+ passwd +"',securityquestion ='"+ securityq +"', securityanswer ='"+ securitya +"' where userid='"+ uid +"'")
    #cursor.execute ("update usermaster set username= '%s', password= '%s', usertype= '%s', userstatus= '%s', securityquestion= '%s', securityanswer= '%s' where userid = '%s'" %(userid,username,password,usertype,userstatus,securityquestion,securityanswer))
    cursor.execute("commit")

    userid.delete(0, 'end')
    username.delete(0, 'end')
    password.delete(0, 'end')
    securityquestion.delete(0, 'end')
    securityanswer.delete(0, 'end')
    messagebox.showinfo("Update Status","Update successfully")
    con.close()




window=Tk()
window.title("User Account Detail")
window.configure(bg='#0B446D')
p1=PhotoImage(file='logos.png')
window.iconphoto(False,p1)

lbl8=Label(window,text="User Account Detail",fg="white" ,bg='#292F68',font=("arial",30,'bold'),bd=6,relief=GROOVE)

lbl1=Label(window,text="Userid",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl2=Label(window,text="Username",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl3=Label(window,text="Password",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl4=Label(window,text="User Type",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl5=Label(window,text="User Status",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl6=Label(window,text="Security Question",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl7=Label(window,text="Security Answer",fg="white",bg='#0B446D',font=('arial',14,'bold'))

firsticon=PhotoImage(file='button_first.png')
previousicon=PhotoImage(file='buttons_17.png')
next1icon=PhotoImage(file='buttons_12.png')
lasticon=PhotoImage(file='button_last.png')
addicon=PhotoImage(file='buttons_11.png')
updateicon=PhotoImage(file='arrow_clockwise.png')
saveicon=PhotoImage(file='tick.png')
cancelicon=PhotoImage(file='delete.png')

userid=Entry(window,bd=4,width=10,bg='#F0F8FF',font=('arial',14))
username=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
password=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
securityanswer=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))

first=Button(window,compound=LEFT,width=100,image=firsticon,text="First",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=first)
previous=Button(window,compound=LEFT,width=100,image=previousicon,text="Previous",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=previous)
next1=Button(window,compound=LEFT,width=100,image=next1icon,text="Next",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=next1)
last=Button(window,compound=LEFT,width=100,image=lasticon,text="Last",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=last)
add=Button(window,compound=LEFT,width=100,image=addicon,text="Add",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=add)
update=Button(window,compound=LEFT,width=100,image=updateicon,text="Update",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=update)
save=Button(window,compound=LEFT,width=100,image=saveicon,text="Save",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=save)
cancel=Button(window,compound=LEFT,width=100,image=cancelicon,text="Cancel",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=window.quit)

options = ["What is your school name?",  
                          "What is your nick name?", 
                          "What is your fathers name", 
                          "What is your mothers name", 
                          "What is your brothers name"
          ]
 
var=StringVar()
var.set("Select")


securityquestion=Combobox(window,values=options,textvariable=var,width=19,font=('arial',14))

names = ["Active",  
        "Unactive"
                          
          ]
 
var1=StringVar()
var1.set("Select")

userstatus=Combobox(window,values=names,textvariable=var1,width=19,font=('arial',14))


types = ["Administrator",  
        "Customer",
         "Manager"
                          
          ]
 
var2=StringVar()
var2.set("Select")

usertype=Combobox(window,values=types,textvariable=var2,width=19,font=('arial',14))


lbl8.place(x=1,y=1,relwidth=1)
        
lbl1.place(x=80,y=100)
userid.place(x=280,y=100)
        
lbl2.place(x=80,y=150)
username.place(x=280,y=150)
          
lbl3.place(x=80,y=200)
password.place(x=280,y=200)
        
lbl4.place(x=80,y=250)
usertype.place(x=280,y=250)

lbl5.place(x=80,y=300)
userstatus.place(x=280,y=300)

lbl6.place(x=80,y=350)
securityquestion.place(x=280,y=350)

lbl7.place(x=80,y=400)
securityanswer.place(x=280,y=400)

first.place(x=100,y=500)
previous.place(x=250,y=500)
next1.place(x=400,y=500)
last.place(x=550,y=500)
add.place(x=100,y=570)
save.place(x=250,y=570)
update.place(x=400,y=570)
cancel.place(x=550,y=570)

image=Image.open("user.png")
image = image.resize((150, 250), Image.ANTIALIAS)
photo=ImageTk.PhotoImage(image)
lbl=Label(window,image=photo,bg='#0B446D')
lbl.place(x=600,y=120)

window.geometry("800x650+200+100")
window.mainloop()