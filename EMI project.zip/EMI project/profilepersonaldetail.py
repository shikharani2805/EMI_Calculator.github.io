from tkinter import *
from tkinter import messagebox
import pymysql
pymysql.install_as_MySQLdb()
from PIL import Image,ImageTk 

def save():
	uid = userid.get()
	uname = username.get()
	dob = dateofbirth.get()
	adrs = address.get()
	mob = mobile.get()
	em = email.get()
	if(uid =="" and uname =="" and adrs==""):
		messagebox.showinfo("Insert Status","All * Fields are required")
	else:
		con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator") 
		cursor = con.cursor()
		cursor.execute("insert into profilepersonalmaster values('"+ uid +"','"+ uname +"','"+ dob +"','"+ adrs +"','"+ mob +"','"+ em +"')")
		cursor.execute("commit")

		userid.delete(0, 'end')
		username.delete(0, 'end')
		dateofbirth.delete(0, 'end')
		address.delete(0, 'end')
		mobile.delete(0, 'end')
		email.delete(0, 'end')
		messagebox.showinfo("Insert Status","Insert successfully")
		con.close()

def update():
	uid = userid.get()
	uname = username.get()
	dob = dateofbirth.get()
	adrs = address.get()
	mob = mobile.get()
	em = email.get()
	if(uid =="" and uname =="" and adrs== ""):
		messagebox.showinfo("update Status","All * Fields are required")
	else:
		con = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator") 
		cursor = con.cursor()
		#cursor.execute("update profilepersonalmaster set  uname ='"+ uname +"',dateofbirth ='"+ dob +"', address ='"+ adrs +"', mobile='"+ mob +"', email='"+ em +"' where userid='"+ userid +"'")
		cursor.execute ("update profilepersonalmaster set username= '%s', dateofbirth= '%s', address= '%s', mobile= '%s', email= '%s' where userid = '%s'" %(uid,uname,dob,adrs,mob,em))
		cursor.execute("commit")

		userid.delete(0, 'end')
		username.delete(0, 'end')
		dateofbirth.delete(0, 'end')
		address.delete(0, 'end')
		mobile.delete(0, 'end')
		email.delete(0, 'end')
		messagebox.showinfo("Update Status","Update successfully")
		con.close()



window=Tk()
window.title('Profile Personal Detail')
window.configure(bg='#0B446D')
p1=PhotoImage(file='logos.png')
window.iconphoto(False,p1)
var=StringVar()
lbl=Label(window,text="Profile Personal Detail",fg="white" ,bg='#292F68',font=("arial",30,'bold'),bd=6,relief=GROOVE)

lbl1=Label(window,text="User Id",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl2=Label(window,text="Name*",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl3=Label(window,text="Date Of Birth*",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl4=Label(window,text="Address*",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl6=Label(window,text="Mobile*",fg="white",bg='#0B446D',font=('arial',14,'bold'))
lbl7=Label(window,text="Email*",fg="white",bg='#0B446D',font=('arial',14,'bold'))
 
       
userid=Entry(window,bd=4,width=10,bg='#F0F8FF',font=('arial',14)) 
username=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
dateofbirth=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
address=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
#address = Text(window,height=4, width=30,bd=4) 
mobile=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))
email=Entry(window,bd=4,width=20,bg='#F0F8FF',font=('arial',14))

updateicon=PhotoImage(file='arrow_clockwise.png')
saveicon=PhotoImage(file='tick.png')
Cancelicon=PhotoImage(file='delete.png')

update=Button(window,compound=LEFT,width=100,image=updateicon,text="Update",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command =update)
save=Button(window,compound=LEFT,width=100,image=saveicon,text="Save",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command =save)
Cancel=Button(window,compound=LEFT,width=100,image=Cancelicon,text="Cancel",padx=12,fg="white",bg='#736FAF',font=('arial',10,'bold'),command=window.quit)
 

lbl.place(x=1,y=1,relwidth=1)

lbl1.place(x=80,y=120)
userid.place(x=250,y=120)
        
lbl2.place(x=80,y=190)
username.place(x=250,y=190)
        
lbl3.place(x=80,y=260)
dateofbirth.place(x=250,y=260)
        
lbl4.place(x=80,y=330)
address.place(x=250,y=330)
        
lbl6.place(x=80,y=400)
mobile.place(x=250,y=400)
        
lbl7.place(x=80,y=470)
email.place(x=250,y=470)

update.place(x=150,y=570)
save.place(x=300,y=570)
Cancel.place(x=450,y=570)

image=Image.open("login.png")
image = image.resize((200, 280), Image.ANTIALIAS)
photo=ImageTk.PhotoImage(image)
lbl=Label(window,image=photo,bg='#0B446D')
lbl.place(x=560,y=150)


window.geometry("800x650+200+100")
window.mainloop()