# Login page
import sys
import os
import pymysql
pymysql.install_as_MySQLdb()
#import MySQLdb
from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox 
def login() :
    db = pymysql.connect(host ="localhost", user = "root", password = "root", db ="emiloancalculator") 
    cur = db.cursor()
    username.get()
    password.get()
    cur.execute("select * from loginpage where username = '%s' and password = '%s'")
    rud = cur.fetchall()
    print("login successfully")    
    cur.close()
    db.close() 
    os.system('python framepage.py')       
return
def forget_password():
    messagebox.askquestion("reset", "Are you sure?")



window=Tk()
window.title('LOGIN PAGE')
window.configure(bg='#BDEDFF')

p1=PhotoImage(file='loginlogo3.png')
window.iconphoto(False,p1)

userlbl=Label(window,text="User Name",fg="#151B54",bg='#BDEDFF',font=("arial",16,'bold'))
#userlbl = Entry(window)
userlbl.place(x=80,y=120)
uasslbl=Label(window,text="Password",fg="#151B54",bg='#BDEDFF',font=("arial",16,'bold'))
uasslbl.place(x=80,y=200)
username=Entry(window,bd=7,width=18,bg = "light gray", fg = "black",font=("arial",16,'bold'))
username.place(x=260,y=120)
password=Entry(window,bd=7,width=18,bg = "light gray",show="*",fg = "black",font=("arial",16,'bold')) 
password.place(x=260,y=200)

subbtn=Button(window,text="SUBMIT",width=10,padx=12,bd=8,bg='#157DEC',font=('arial',10,'bold'), command=login)
subbtn.place(x=350,y=300)

forbtn=Button(window,text="Forget Password!",width=15,padx=12,bd=8,bg='#3BB9FF',font=('arial',10,'bold'),command = forget_password)    
forbtn.place(x=100,y=300)

image=Image.open("login2.png")
image = image.resize((550, 70), Image.ANTIALIAS)
photo=ImageTk.PhotoImage(image)
lbl=Label(window,image=photo)
lbl.pack(pady=2,padx=0)

window.geometry("550x400+300+200")
window.mainloop()